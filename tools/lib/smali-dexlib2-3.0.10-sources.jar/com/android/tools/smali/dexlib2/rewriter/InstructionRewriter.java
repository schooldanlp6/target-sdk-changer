/*
 * Copyright 2014, Google LLC
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above
 * copyright notice, this list of conditions and the following disclaimer
 * in the documentation and/or other materials provided with the
 * distribution.
 *     * Neither the name of Google LLC nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.android.tools.smali.dexlib2.rewriter;

import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.ReferenceType;
import com.android.tools.smali.dexlib2.iface.instruction.DualReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction20bc;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction21c;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction22c;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction31c;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction35c;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction3rc;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction45cc;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction4rcc;
import com.android.tools.smali.dexlib2.iface.reference.CallSiteReference;
import com.android.tools.smali.dexlib2.iface.reference.FieldReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodHandleReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodProtoReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.iface.reference.Reference;
import com.android.tools.smali.dexlib2.iface.reference.TypeReference;
import com.android.tools.smali.util.ExceptionWithContext;

import javax.annotation.Nonnull;

public class InstructionRewriter implements Rewriter<Instruction> {
    @Nonnull protected final Rewriters rewriters;

    public InstructionRewriter(@Nonnull Rewriters rewriters) {
        this.rewriters = rewriters;
    }

    @Nonnull @Override public Instruction rewrite(@Nonnull Instruction instruction) {
        if (instruction instanceof ReferenceInstruction) {
            switch (instruction.getOpcode().format) {
                case Format20bc:
                    return new RewrittenInstruction20bc((Instruction20bc)instruction);
                case Format21c:
                    return new RewrittenInstruction21c((Instruction21c)instruction);
                case Format22c:
                    return new RewrittenInstruction22c((Instruction22c)instruction);
                case Format31c:
                    return new RewrittenInstruction31c((Instruction31c)instruction);
                case Format35c:
                    return new RewrittenInstruction35c((Instruction35c)instruction);
                case Format3rc:
                    return new RewrittenInstruction3rc((Instruction3rc)instruction);
                case Format45cc:
                    return new RewrittenInstruction45cc((Instruction45cc) instruction);
                case Format4rcc:
                    return new RewrittenInstruction4rcc((Instruction4rcc) instruction);
                default:
                    throw new IllegalArgumentException();
            }
        }
        return instruction;
    }

    @Nonnull private Reference rewriteReference(int type,
                                                @Nonnull Reference reference) {
        switch (type) {
            case ReferenceType.TYPE:
                return RewriterUtils.rewriteTypeReference(rewriters.getTypeRewriter(),
                        (TypeReference)reference);
            case ReferenceType.FIELD:
                return rewriters.getFieldReferenceRewriter().rewrite((FieldReference)reference);
            case ReferenceType.METHOD:
                return rewriters.getMethodReferenceRewriter().rewrite((MethodReference)reference);
            case ReferenceType.STRING:
                return reference;
            case ReferenceType.METHOD_PROTO:
                return RewriterUtils.rewriteMethodProtoReference(
                        rewriters.getTypeRewriter(),
                        (MethodProtoReference)reference);
            case ReferenceType.METHOD_HANDLE:
                return RewriterUtils.rewriteMethodHandleReference(
                        rewriters, (MethodHandleReference)reference);
            case ReferenceType.CALL_SITE:
                return rewriters.getCallSiteReferenceRewriter().rewrite((CallSiteReference)reference);
            default:
                throw new ExceptionWithContext("Invalid reference type: %d",
                                type);
        }
    }

    protected class BaseRewrittenReferenceInstruction<T extends ReferenceInstruction>
            implements ReferenceInstruction {
        @Nonnull protected T instruction;

        protected BaseRewrittenReferenceInstruction(@Nonnull T instruction) {
            this.instruction = instruction;
        }

        @Override @Nonnull public Reference getReference() {
            return rewriteReference(
                instruction.getReferenceType(), instruction.getReference());
        }

        @Override public int getReferenceType() {
            return instruction.getReferenceType();
        }

        @Override public Opcode getOpcode() {
            return instruction.getOpcode();
        }

        @Override public int getCodeUnits() {
            return instruction.getCodeUnits();
        }
    }

    protected class RewrittenInstruction20bc extends BaseRewrittenReferenceInstruction<Instruction20bc>
            implements Instruction20bc {
        public RewrittenInstruction20bc(@Nonnull Instruction20bc instruction) {
            super(instruction);
        }

        @Override public int getVerificationError() {
            return instruction.getVerificationError();
        }
    }

    protected class RewrittenInstruction21c extends BaseRewrittenReferenceInstruction<Instruction21c>
            implements Instruction21c {
        public RewrittenInstruction21c(@Nonnull Instruction21c instruction) {
            super(instruction);
        }

        public int getRegisterA() {
            return instruction.getRegisterA();
        }
    }

    protected class RewrittenInstruction22c extends BaseRewrittenReferenceInstruction<Instruction22c>
            implements Instruction22c {
        public RewrittenInstruction22c(@Nonnull Instruction22c instruction) {
            super(instruction);
        }

        public int getRegisterA() {
            return instruction.getRegisterA();
        }

        public int getRegisterB() {
            return instruction.getRegisterB();
        }
    }

    protected class RewrittenInstruction31c extends BaseRewrittenReferenceInstruction<Instruction31c>
            implements Instruction31c {
        public RewrittenInstruction31c(@Nonnull Instruction31c instruction) {
            super(instruction);
        }

        public int getRegisterA() {
            return instruction.getRegisterA();
        }
    }

    protected class RewrittenInstruction35c extends BaseRewrittenReferenceInstruction<Instruction35c>
            implements Instruction35c {
        public RewrittenInstruction35c(@Nonnull Instruction35c instruction) {
            super(instruction);
        }

        public int getRegisterC() {
            return instruction.getRegisterC();
        }

        public int getRegisterE() {
            return instruction.getRegisterE();
        }

        public int getRegisterG() {
            return instruction.getRegisterG();
        }

        public int getRegisterCount() {
            return instruction.getRegisterCount();
        }

        public int getRegisterD() {
            return instruction.getRegisterD();
        }

        public int getRegisterF() {
            return instruction.getRegisterF();
        }
    }

    protected class RewrittenInstruction3rc extends BaseRewrittenReferenceInstruction<Instruction3rc>
            implements Instruction3rc {
        public RewrittenInstruction3rc(@Nonnull Instruction3rc instruction) {
            super(instruction);
        }

        public int getStartRegister() {
            return instruction.getStartRegister();
        }

        public int getRegisterCount() {
            return instruction.getRegisterCount();
        }
    }

    protected class BaseRewrittenDualReferenceInstruction<T extends DualReferenceInstruction>
            extends BaseRewrittenReferenceInstruction<T>
            implements DualReferenceInstruction {
        public BaseRewrittenDualReferenceInstruction(@Nonnull T instruction) {
            super(instruction);
        }

        @Nonnull public Reference getReference2() {
            return rewriteReference(
                instruction.getReferenceType2(), instruction.getReference2());
        }

        public int getReferenceType2() {
            return instruction.getReferenceType2();
        }
    }

    protected class RewrittenInstruction45cc extends BaseRewrittenDualReferenceInstruction<Instruction45cc>
            implements Instruction45cc {
        public RewrittenInstruction45cc(@Nonnull Instruction45cc instruction) {
            super(instruction);
        }

        public int getRegisterC() {
            return instruction.getRegisterC();
        }

        public int getRegisterE() {
            return instruction.getRegisterE();
        }

        public int getRegisterG() {
            return instruction.getRegisterG();
        }

        public int getRegisterCount() {
            return instruction.getRegisterCount();
        }

        public int getRegisterD() {
            return instruction.getRegisterD();
        }

        public int getRegisterF() {
            return instruction.getRegisterF();
        }
    }

    protected class RewrittenInstruction4rcc extends BaseRewrittenDualReferenceInstruction<Instruction4rcc>
            implements Instruction4rcc {
        public RewrittenInstruction4rcc(@Nonnull Instruction4rcc instruction) {
            super(instruction);
        }

        public int getStartRegister() {
            return instruction.getStartRegister();
        }

        public int getRegisterCount() {
            return instruction.getRegisterCount();
        }
    }
}
